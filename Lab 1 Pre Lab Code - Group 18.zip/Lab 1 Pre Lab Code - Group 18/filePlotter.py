import matplotlib.pyplot as plt
from utilities import FileReader

def plot_errors(filenames):
    # Determine the number of files
    num_files = len(filenames)

    # Create a figure and as many subplots as there are files (1 row, 3 columns)
    fig, axes = plt.subplots(nrows=num_files, ncols=1, figsize=(15, 5))

    # In case there is only one file, we need to make axes iterable
    if num_files == 1:
        axes = [axes]

    # Loop through each file and plot data in separate subplots
    for idx, filename in enumerate(filenames):
        headers, values = FileReader(filename).read_file()
        time_list = []
        first_stamp = values[0][-1]

        for val in values:
            time_list.append(val[-1] - first_stamp)

        for i in range(len(headers) - 1):
            axes[idx].plot(time_list, [lin[i] for lin in values], label=headers[i] + " linear")

        # Add labels and titles to each subplot
        axes[idx].set_xlabel('Time (seconds)')
        axes[idx].set_ylabel('Sensor Values')
        axes[idx].set_title(f"Sensor Data Plot for {filename}")
        axes[idx].legend()
        axes[idx].grid()

    # Adjust layout to make sure everything fits
    plt.tight_layout()
    plt.show()

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some files.')
    parser.add_argument('--files', nargs='+', required=True, help='List of files to process')

    args = parser.parse_args()

    print("plotting the files", args.files)

    filenames = args.files
    plot_errors(filenames)
